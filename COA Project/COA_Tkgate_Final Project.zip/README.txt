COA Tkgate Final Project
Date submitted - 24/10/2020

Group members :

19ucc002- Madhur Verma
19ucc023- Mohit Akhouri
19ucc026- Divyansh Rastogi
19ucc043- Aditya Pandey

Screenshots of "main module" and "alu module" are attached in this file
The ISA document for the CPU design is the same as before

